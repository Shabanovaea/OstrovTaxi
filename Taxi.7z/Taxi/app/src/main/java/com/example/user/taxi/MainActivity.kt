package com.example.user.taxi


import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import android.widget.Toast
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError





class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun check(view: View) {
        if (editText.text.isEmpty()) {
            val textString = "Запрос пуст"
            val toastMe = Toast.makeText(this, textString, Toast.LENGTH_SHORT)
            toastMe.show()
        } else {

            val toastMe = Toast.makeText(this, editText.text.toString(), Toast.LENGTH_SHORT)
            toastMe.show()
        }
    }

    fun request() {
        val referance = FirebaseDatabase.getInstance().reference
        val myQuery = referance.orderByChild("VehicleNumber").equalTo("Р642НР197")
        val PostListener = object : ValueEventListener {
            override fun onDataChange(p0: DataSnapshot?) {
               if p0 != null) {

                    this@MainActivity.status = p0.children.first().childrenelement(11).value as String
                }
            }

            override fun onCancelled(p0: DatabaseError?) {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }
        }

    }
}